<?php
namespace Models;

use Interfaces\Locavel;

/**
 * Classe que representa um serviço de Banho no sistema
 */
class Carro extends Veiculo implements Locavel {

    // Calcula o valor do serviço
    public function calcularAluguel(int $dias): float {
        return $dias * DIARIA_BANHO;
    }

    // Reserva o serviço
    public function alugar(): string {
        if ($this->disponivel) {
            $this->disponivel = false;
            return "Serviço '{$this->modelo}' reservado com sucesso! 🐶";
        }

        return "Serviço '{$this->modelo}' não está disponível no momento.";
    }

    // Finaliza a reserva
    public function devolver(): string {
        if (!$this->disponivel) {
            $this->disponivel = true;
            return "Serviço '{$this->modelo}' finalizado com sucesso! 🛁";
        }

        return "O serviço '{$this->modelo}' já está disponível.";
    }
}