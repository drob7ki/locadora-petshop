<?php
namespace Models;

use Interfaces\Locavel;

/**
 * Classe que representa um serviço pet no sistema
 */
class Moto extends Veiculo implements Locavel {

    // Calcula o valor do serviço
    public function calcularAluguel(int $dias): float {
        return $dias * DIARIA_HOSPEDAGEM;
    }

    // Reserva o serviço
    public function alugar(): string {
        if ($this->disponivel) {
            $this->disponivel = false;
            return "Serviço '{$this->modelo}' reservado com sucesso! 🐾";
        }

        return "Serviço '{$this->modelo}' não está disponível.";
    }

    // Finaliza o serviço
    public function devolver(): string {
        if (!$this->disponivel) {
            $this->disponivel = true;
            return "Serviço '{$this->modelo}' finalizado com sucesso! ✨";
        }

        return "Serviço '{$this->modelo}' já está disponível.";
    }
}