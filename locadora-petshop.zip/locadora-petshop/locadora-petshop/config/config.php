<?php
// ================================
// CONFIGURAÇÕES DO SISTEMA PETSHOP
// ================================

// Caminhos dos arquivos JSON
define('ARQUIVO_JSON', __DIR__ . '/../data/veiculos.json');
define('ARQUIVO_USUARIOS', __DIR__ . '/../data/usuarios.json');

// Valores das diárias
define('DIARIA_BANHO', 80.00);
define('DIARIA_HOSPEDAGEM', 120.00);

// Nome do sistema
define('NOME_SISTEMA', 'PetLoc - Locadora Petshop');

// Tema visual
define('COR_PRIMARIA', '#ff914d');
define('COR_SECUNDARIA', '#4ecdc4');
?>