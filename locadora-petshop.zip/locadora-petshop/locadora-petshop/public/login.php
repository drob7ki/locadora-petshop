<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/config.php';

session_start();

use Services\Auth;

$mensagem = '';
$auth = new Auth();

// Se já estiver logado, redireciona para index
if (Auth::verificarLogin()) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($auth->login($username, $password)) {

        header('Location: index.php');
        exit;

    } else {

        $mensagem = 'Usuário ou senha inválidos 🐾';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PetLoc</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background: linear-gradient(135deg, #fff6ec, #ffe0cc);
            font-family: Arial, sans-serif;
        }

        .login-container{
            max-width: 420px;
            margin: 80px auto;
        }

        .card{
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            overflow: hidden;
        }

        .card-header{
            background: #ff914d;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .card-header h4{
            margin: 0;
            font-weight: bold;
        }

        .card-body{
            padding: 30px;
            background: white;
        }

        .form-control{
            border-radius: 12px;
            padding: 12px;
        }

        .btn-primary{
            background: #ff914d;
            border: none;
            border-radius: 12px;
            padding: 12px;
            font-weight: bold;
        }

        .btn-primary:hover{
            background: #ff7b29;
        }

        .pet-icon{
            font-size: 50px;
            margin-bottom: 10px;
        }

    </style>
</head>

<body>

    <div class="login-container">

        <div class="card">

            <div class="card-header">
                <div class="pet-icon">🐶</div>
                <h4>PetLoc</h4>
                <small>Sistema de Serviços Petshop</small>
            </div>

            <div class="card-body">

                <?php if ($mensagem): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($mensagem) ?>
                    </div>
                <?php endif; ?>

                <form method="post" class="needs-validation" novalidate>

                    <div class="mb-3">
                        <label class="form-label">Usuário</label>

                        <input
                            type="text"
                            name="username"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Senha</label>

                        <input
                            type="password"
                            name="password"
                            class="form-control"
                            required
                        >
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        Entrar no PetLoc 🐾
                    </button>

                </form>

            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>