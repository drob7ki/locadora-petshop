<?php
namespace Interfaces;

/**
 * Interface que define os métodos necessários
 * para um serviço pet ser reservado
 */
interface Locavel {

    // Reserva um serviço ou espaço do petshop
    public function alugar(): string;

    // Finaliza a reserva
    public function devolver(): string;

    // Verifica disponibilidade
    public function isDisponivel(): bool;
}