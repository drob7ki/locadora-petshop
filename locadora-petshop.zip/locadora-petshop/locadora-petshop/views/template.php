<?php
require_once __DIR__ . '/../services/Auth.php';

use Services\Auth;

$usuario = Auth::getUsuario();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetLoc - Sistema Petshop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
    background:
    linear-gradient(135deg,#fff7f0,#ffe8d6,#fff2e6);
    min-height:100vh;
    font-family:'Segoe UI',sans-serif;
    color:#444;
}

h1,h4{
    font-weight:700;
    color:#5a3726;
}

.card{
    background:white;
    border:none;
    border-radius:25px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

.card-header{
    background:linear-gradient(90deg,#ff914d,#ffb26b);
    color:white;
    border:none;
}

.form-control,
.form-select{
    border-radius:14px;
    border:1px solid #ffd2b3;
    padding:12px;
}

.form-control:focus,
.form-select:focus{
    border-color:#ff914d;
    box-shadow:0 0 10px rgba(255,145,77,0.25);
}

.table{
    color:#5a3726;
}

.table-striped > tbody > tr:nth-of-type(odd){
    background-color:rgba(255,145,77,0.04);
}

.action-wrapper{
    display:flex;
    align-items:center;
    gap:0.5rem;
}

.btn-group-actions{
    display:flex;
    gap:0.5rem;
    align-items:center;
}

.rent-group{
    display:flex;
    align-items:center;
    gap:0.5rem;
}

.days-input{
    width:65px !important;
}

.user-info{
    background:white;
    border-radius:20px;
    padding:0.8rem 1rem;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
}

.welcome-text strong{
    background:#ff914d;
    color:white;
    padding:0.3rem 0.7rem;
    border-radius:10px;
}

.btn-primary{
    background:#ff914d;
    border:none;
}

.btn-primary:hover{
    background:#ff7a26;
}

.btn-info{
    background:#4ecdc4;
    border:none;
    color:white;
}

.btn-info:hover{
    background:#34b3aa;
    color:white;
}

.btn-danger{
    border:none;
}

.pet-title{
    display:flex;
    align-items:center;
    gap:12px;
}

.pet-title span{
    font-size:45px;
}

.badge{
    padding:8px 12px;
    border-radius:10px;
}

@media (max-width:768px){

    .action-wrapper,
    .btn-group-actions,
    .rent-group{
        flex-direction:column;
        width:100%;
    }

    .days-input{
        width:100% !important;
    }
}

</style>
</head>

<body class="container py-4">

<div class="container py-4">

    <!-- TOPO -->
    <div class="row mb-4">

        <div class="col-12">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div class="pet-title">
                    <span>🐾</span>
                    <h1 class="m-0">PetLoc</h1>
                </div>

                <div class="d-flex align-items-center gap-3 user-info">

                    <span>
                        <i class="bi bi-person-circle" style="font-size:24px;"></i>
                    </span>

                    <span class="welcome-text">
                        Bem-vindo,
                        <strong><?= htmlspecialchars($usuario['username']) ?></strong>
                    </span>

                    <a href="?logout=1"
                       class="btn btn-outline-danger d-flex align-items-center gap-1">

                        <i class="bi bi-box-arrow-right"></i>
                        Sair
                    </a>

                </div>
            </div>
        </div>
    </div>

    <!-- ALERTA -->
    <?php if ($mensagem): ?>

    <div class="alert alert-info alert-dismissible fade show" role="alert">

        <?= htmlspecialchars($mensagem) ?>

        <button type="button"
                class="btn-close"
                data-bs-dismiss="alert">
        </button>

    </div>

    <?php endif; ?>

    <div class="row same-height-row">

        <!-- ADICIONAR -->
        <?php if (Auth::isAdmin()): ?>

        <div class="col-md-6 mb-4">

            <div class="card h-100">

                <div class="card-header">
                    <h4 class="mb-0">Adicionar Novo Serviço 🐶</h4>
                </div>

                <div class="card-body">

                    <form method="post">

                        <div class="mb-3">

                            <label class="form-label">
                                Nome do Serviço
                            </label>

                            <input type="text"
                                   name="modelo"
                                   class="form-control"
                                   required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Código
                            </label>

                            <input type="text"
                                   name="placa"
                                   class="form-control"
                                   required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Tipo de Serviço
                            </label>

                            <select name="tipo"
                                    class="form-select"
                                    required>

                                <option value="Carro">
                                    Banho
                                </option>

                                <option value="Moto">
                                    Hospedagem
                                </option>

                            </select>
                        </div>

                        <button type="submit"
                                name="adicionar"
                                class="btn btn-primary w-100">

                            Adicionar Serviço
                        </button>

                    </form>
                </div>
            </div>
        </div>

        <?php endif; ?>

        <!-- CALCULAR -->
        <div class="col-<?= Auth::isAdmin() ? 'md-6' : '12' ?> mb-4">

            <div class="card h-100">

                <div class="card-header">
                    <h4 class="mb-0">Calcular Valor do Serviço ✨</h4>
                </div>

                <div class="card-body">

                    <form method="post">

                        <div class="mb-3">

                            <label class="form-label">
                                Tipo de Serviço
                            </label>

                            <select name="tipo_calculo"
                                    class="form-select"
                                    required>

                                <option value="Carro">
                                    Banho
                                </option>

                                <option value="Moto">
                                    Hospedagem
                                </option>

                            </select>
                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Quantidade de Dias
                            </label>

                            <input type="number"
                                   name="dias_calculo"
                                   class="form-control"
                                   value="1"
                                   required>

                        </div>

                        <button type="submit"
                                name="calcular"
                                class="btn btn-info w-100">

                            Calcular Previsão
                        </button>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- TABELA -->
    <div class="row">

        <div class="col-12">

            <div class="card">

                <div class="card-header">
                    <h4 class="mb-0">
                        Serviços Disponíveis 🐾
                    </h4>
                </div>

                <div class="card-body">

                    <div class="table-responsive">

                        <table class="table table-striped">

                            <thead>

                            <tr>
                                <th>Tipo</th>
                                <th>Serviço</th>
                                <th>Código</th>
                                <th>Status</th>

                                <?php if (Auth::isAdmin()): ?>
                                    <th>Ações</th>
                                <?php endif; ?>

                            </tr>

                            </thead>

                            <tbody>

                            <?php foreach ($locadora->listarVeiculos() as $veiculo): ?>

                            <tr>

                                <td>
                                    <?= $veiculo instanceof \Models\Carro
                                        ? 'Banho'
                                        : 'Hospedagem' ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($veiculo->getModelo()) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($veiculo->getPlaca()) ?>
                                </td>

                                <td>

                                    <span class="badge bg-<?= $veiculo->isDisponivel()
                                        ? 'success'
                                        : 'warning' ?>">

                                        <?= $veiculo->isDisponivel()
                                            ? 'Disponível'
                                            : 'Reservado' ?>

                                    </span>

                                </td>

                                <?php if (Auth::isAdmin()): ?>

                                <td>

                                    <div class="action-wrapper">

                                        <form method="post"
                                              class="btn-group-actions">

                                            <input type="hidden"
                                                   name="modelo"
                                                   value="<?= htmlspecialchars($veiculo->getModelo()) ?>">

                                            <input type="hidden"
                                                   name="placa"
                                                   value="<?= htmlspecialchars($veiculo->getPlaca()) ?>">

                                            <button type="submit"
                                                    name="deletar"
                                                    class="btn btn-danger btn-sm">

                                                Deletar
                                            </button>

                                            <div class="rent-group">

                                                <?php if (!$veiculo->isDisponivel()): ?>

                                                <button type="submit"
                                                        name="devolver"
                                                        class="btn btn-warning btn-sm">

                                                    Finalizar
                                                </button>

                                                <?php else: ?>

                                                <input type="number"
                                                       name="dias"
                                                       class="form-control days-input"
                                                       value="1"
                                                       min="1"
                                                       required>

                                                <button type="submit"
                                                        name="alugar"
                                                        class="btn btn-primary btn-sm">

                                                    Reservar
                                                </button>

                                                <?php endif; ?>

                                            </div>
                                        </form>
                                    </div>
                                </td>

                                <?php endif; ?>

                            </tr>

                            <?php endforeach; ?>

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>